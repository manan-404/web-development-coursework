// src/App.tsx
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';
import AppNavbar from './Navbar';
import Hero from './Hero';
import Features from './Features';
import Footer from './Footer';

export default function App(): React.JSX.Element {
  return (
    <div className="homepage-wrapper">
      <AppNavbar />
      <Hero />
      <Features />
      <Footer />
    </div>
  );
}
